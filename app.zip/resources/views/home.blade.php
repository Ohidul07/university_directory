@extends('layouts.app')

@section('title','Dashboard | BSMRAU')
@section('header','Dashboard')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8">
            
        </div>
    </div>
</div>
@endsection
