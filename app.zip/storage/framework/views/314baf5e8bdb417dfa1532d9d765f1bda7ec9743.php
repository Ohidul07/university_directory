<div class="container-fluid mt-4">
 <?php echo $__env->yieldContent('content'); ?>   
</div><?php /**PATH C:\university_directory\resources\views/layouts/content.blade.php ENDPATH**/ ?>