<div class="table-responsive">
    <table class="table align-items-center table-flush">
        <thead class="thead-light">
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Designation</th>
                <th scope="col">Category</th>
                <th scope="col">Sub-Category</th>
                <th scope="col">Sub-Sub-Category</th>
                <th scope="col">Contact</th>
                <th scope="col">Email</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="table-user">
                        <?php if($person->image): ?>
                        <img src="<?php echo e($person->image); ?>" class="avatar rounded-circle mr-3">
                        <?php else: ?>
                        <img src="/persons/user.png" class="avatar rounded-circle mr-3">
                        <?php endif; ?>
                        <b><?php echo e($person->name); ?></b>
                    </td>
                    <td><?php echo e($person->designation_name); ?></td>
                    <td><?php echo e($person->category_name); ?></td>
                    <td><?php echo e($person->sub_category_name); ?></td>
                    <td><?php echo e($person->sub_sub_category_name); ?></td>
                    <td><?php echo e($person->contact); ?></td>
                    <td><?php echo e($person->email); ?></td>
                    <td>
                        <button class="btn btn-primary btn-sm" data-target="#editModal" data-toggle="modal" onclick="editValue('<?php echo e($person->id); ?>')" type="button"><i class="fas fa-user-edit"></i></button>
                        <?php if($person->active==1): ?>
                        <button class="btn btn-warning btn-sm" onclick="deactive('<?php echo e($person->id); ?>')" type="button"><i class="fas fa-times"></i></button>
                        <?php else: ?>
                        <button class="btn btn-success btn-sm" onclick="active('<?php echo e($person->id); ?>')" type="button"><i class="fas fa-check"></i></button>
                        <?php endif; ?>
                        <button class="btn btn-danger btn-sm" onclick="deleteValue('<?php echo e($person->id); ?>')" type="button"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="card-footer py-4">
    <nav aria-label="...">
        <?php echo $persons->links(); ?>

    </nav>
</div><?php /**PATH C:\university_directory\resources\views/person/person/list_view.blade.php ENDPATH**/ ?>