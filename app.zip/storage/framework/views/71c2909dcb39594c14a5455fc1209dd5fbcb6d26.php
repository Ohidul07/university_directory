<div class="header bg-gradient-primary pb-5 pt-5 pt-md-4">
      <div class="container-fluid">

      </div>
    </div><?php /**PATH C:\university_directory\resources\views/layouts/header.blade.php ENDPATH**/ ?>