<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Favicon -->
  <link href="<?php echo e(url('assets/img/brand/favicon.png')); ?>" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="<?php echo e(url('assets/js/plugins/nucleo/css/nucleo.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(url('assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" />
  <!-- bootstrap -->
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
  <!-- CSS Files -->
  <link href="<?php echo e(url('assets/css/argon-dashboard.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo e(url('assets/vendor/animate.css/animate.min.css')); ?>">
  <!-- custom css -->
  <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet" />
  <style type="text/css">
    .logout-btn:focus { outline: none; cursor: pointer; }
  </style>
  <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
  <!-- navbar mobile & sidebar  -->
  <?php echo $__env->make('layouts.navbar-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- navbar mobile & sidebar end -->
  <div class="main-content">
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->
    <!-- Header -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header end-->
    <!-- content -->
    <div class="container-fluid mt-4">
     <?php echo $__env->yieldContent('content'); ?>   
    </div>
    <!-- content end -->
  </div>
  <!--   Core   -->
  <script src="<?php echo e(url('assets/js/plugins/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <!--   Argon JS   -->
  <script src="<?php echo e(url('assets/js/argon-dashboard.min.js')); ?>"></script>
  <script src="<?php echo e(url('js/script.js')); ?>"></script>
  <script src="<?php echo e(url('assets/vendor/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH C:\university_directory\resources\views/layouts/app.blade.php ENDPATH**/ ?>