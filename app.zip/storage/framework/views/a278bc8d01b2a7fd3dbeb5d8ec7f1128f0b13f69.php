<?php $__env->startSection('title','Dashboard | BSMRAU'); ?>
<?php $__env->startSection('header','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\university_directory\resources\views/home.blade.php ENDPATH**/ ?>