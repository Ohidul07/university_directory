<?php $__env->startSection('title', 'Persons | BSMRAU'); ?>
<?php $__env->startSection('header', 'Persons'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col">
			<div class="card shadow">
				<div class="card-header border-0">
					<h3 class="mb-0">Person List <button class="btn btn-primary btn-sm" data-target="#exampleModal" data-toggle="modal" id="addCategory" type="button">Add Person</button></h3>
				</div>
				<div class="card-body">
					<div id="itemsDiv">
						<?php echo $__env->make('person.person.list_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<div class="table-loading">
						<i class="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div aria-hidden="true" aria-labelledby="exampleModalLabel" class="modal fade" id="exampleModal" role="dialog" tabindex="-1">
		<div class="modal-dialog modal-dialog-top" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Add Person</h5><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
				</div>
				<form action="/persons/store" id="addForm" method="post" name="addForm" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="modal-body">
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Name</span>
							</div>
							<input class="form-control" id="" name="name" placeholder="Person Full Name" type="text">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Category</span>
							</div>
							<select class="form-control" id="category_id" name="category_id">
								<option value='' selected disabled>Select Category</option>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value='<?php echo e($category->id); ?>'><?php echo e($category->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Sub-Category</span>
							</div>
							<select class="form-control" id="subcategory_id" name="sub_category_id">
								<option selected disabled>Select Sub-Category</option>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Sub-Sub-Category</span>
							</div>
							<select class="form-control" id="subsubcategory_id" name="sub_sub_category_id">
								<option selected disabled>Select Sub-Sub-Category</option>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Designation</span>
							</div>
							<select class="form-control" id="designation_id" name="designation_id">
								<option selected disabled>Select Designation</option>
								<?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value='<?php echo e($designation->id); ?>'><?php echo e($designation->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Contact</span>
							</div>
							<input class="form-control" id="input_name" name="contact" placeholder="Contact number" type="text">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Email</span>
							</div>
							<input class="form-control" id="input_name" name="email" placeholder="Email Address" type="email">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Image</span>
							</div>
							<input class="form-control" id="image" name="image" type="file">
						</div>
					</div>
					<div class="modal-footer">
						<button class="btn btn-secondary btn-sm" data-dismiss="modal" type="button">Close</button> <button class="btn btn-primary btn-sm" type="submit">Add</button>
					</div>
				</form>
			</div>
		</div>
  	</div>

  	<!-- edit modal -->
	<div aria-hidden="true" aria-labelledby="editModalLabel" class="modal fade" id="editModal" role="dialog" tabindex="-1">
		<div class="modal-dialog modal-dialog-top" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="editModalLabel">Edit Person</h5><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
				</div>
				<form action="/persons/update" id="updateForm" method="post" name="updateForm" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="modal-body">
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Name</span>
							</div>
							<input class="form-control" id="edit_name" name="name" placeholder="Person Full Name" type="text">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Category</span>
							</div>
							<select class="form-control" id="edit_category_id" name="category_id">
								<option selected>Select Category</option>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value='<?php echo e($category->id); ?>'><?php echo e($category->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Sub-Category</span>
							</div>
							<select class="form-control" id="edit_subcategory_id" name="sub_category_id">
								<option selected>Select Sub-Category</option>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Sub-Sub-Category</span>
							</div>
							<select class="form-control" id="edit_subsubcategory_id" name="sub_sub_category_id">
								<option selected>Select Sub-Sub-Category</option>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Designation</span>
							</div>
							<select class="form-control" id="edit_designation_id" name="designation_id">
								<option selected disabled>Select Designation</option>
								<?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value='<?php echo e($designation->id); ?>'><?php echo e($designation->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Contact</span>
							</div>
							<input class="form-control" id="edit_contact" name="contact" placeholder="Contact number" type="text">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Email</span>
							</div>
							<input class="form-control" id="edit_email" name="email" placeholder="Email Address" type="email">
						</div>
						<div class="input-group input-group-sm mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text input-bg">Image</span>
							</div>
							<input class="form-control" id="image" name="image" type="file">
						</div>
						<img src="#" style="width: 100px;" id="edit_image">
            			<input type="hidden" name="id" id="edit_id">
					</div>
					<div class="modal-footer">
						<button class="btn btn-secondary btn-sm" data-dismiss="modal" type="button">Close</button> <button class="btn btn-primary btn-sm" type="submit">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#addForm').submit(function(e){
		e.preventDefault();
		$('.table-loading').css('display','block');
		$.ajax({
			url: '/persons/store',
			dataType: 'text',
			cache: false,
			contentType: false,
			processData: false,
			data: new FormData(this),
			type: 'post',
			success: function(data){
				if(data==1){
	                $('#exampleModal').modal('toggle');
	                $.notifyDefaults({
	                    type: 'success',
	                    allow_dismiss: true
	                });
					$.notify('Person added successfully.');
					var page = $('.pagination').find('.active').children().html();
					getItems('/persons/list?page='+page,'itemsDiv');
	            }
	            else{
	                $('#exampleModal').modal('toggle');
	                $.notifyDefaults({
	                    type: 'danger',
	                    allow_dismiss: true
	                });
					$.notify('Try again.Something wrong.');
					$('.table-loading').css('display','none');
	            }
			},
			error: function(data){
				$('.table-loading').css('display','none');
			}
		});
    });

    function editValue(id){
      $.get('/persons/edit/'+id,function(data){
          $('#edit_name').val(data['person'][0].name);
          $('#edit_category_id').val(data['person'][0].category_id);
          $('#edit_designation_id').val(data['person'][0].designation_id);
          $('#edit_contact').val(data['person'][0].contact);
          $('#edit_email').val(data['person'][0].email);
          $('#edit_id').val(data['person'][0].id);
          $('#edit_image').attr('src',data['person'][0].image);

          var html = '';
		  html += '<option value="" selected>Select Sub-Category</option>';
		  $.each(data['sub_categories'],function(key,value){
			html += '<option value="'+value.id+'">'+value.name+'</option>';
		  });
		  $('#edit_subcategory_id').html(html);
		  $('#edit_subcategory_id').val(data['person'][0].sub_category_id);

		  var html2 = '';
		  html2 += '<option value="" selected>Select Sub-Sub-Category</option>';
		  $.each(data['sub_sub_categories'],function(key,value){
			html2 += '<option value="'+value.id+'">'+value.name+'</option>';
		  });
		  $('#edit_subsubcategory_id').html(html2);
		  $('#edit_subsubcategory_id').val(data['person'][0].sub_sub_category_id);

	  }).fail(function(data){

      });
    }

    function deleteValue(id){
		$('.table-loading').css('display','block');
		var page = $('.pagination').find('.active').children().html();
		ask('/persons/delete/'+id,'Designation deleted successfully','/persons/list?page='+page);
    }

    function active(id){
		$('.table-loading').css('display','block');
		var page = $('.pagination').find('.active').children().html();
		ask('/persons/active/'+id,'Designation activated successfully','/persons/list?page='+page);
    }

    function deactive(id){
		$('.table-loading').css('display','block');
		var page = $('.pagination').find('.active').children().html();
		ask('/persons/deactive/'+id,'Designation deactivated successfully','/persons/list?page='+page);
    }

    $('#updateForm').submit(function(e){
		e.preventDefault();
		$('.table-loading').css('display','block');
		$.ajax({
			url: '/persons/update',
			dataType: 'text',
			cache: false,
			contentType: false,
			processData: false,
			data: new FormData(this),
			type: 'post',
			success: function(data){
				if(data==1){
	                $('#exampleModal').modal('toggle');
	                $.notifyDefaults({
	                    type: 'success',
	                    allow_dismiss: true
	                });
					$.notify('Person Updated successfully.');
					var page = $('.pagination').find('.active').children().html();
					getItems('/persons/list?page='+page,'itemsDiv');
	            }
	            else{
	                $('#exampleModal').modal('toggle');
	                $.notifyDefaults({
	                    type: 'danger',
	                    allow_dismiss: true
	                });
					$.notify('Try again.Something wrong.');
					$('.table-loading').css('display','none');
	            }
			},
			error: function(data){
				$('.table-loading').css('display','none');
			}
		});
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\university_directory\resources\views/person/person/list.blade.php ENDPATH**/ ?>